#include <stdio.h>
int main()
{
    if (1)
    {
        printf("Hello Harendra");
    }
    return 1;
}
